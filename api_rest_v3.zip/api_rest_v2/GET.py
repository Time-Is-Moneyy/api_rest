import requests

response = requests.get('http://localhost:5000/users/1')
if response.status_code == 200:
    task = response.json()
    print(task)

else:
    print('Error:', response.text)
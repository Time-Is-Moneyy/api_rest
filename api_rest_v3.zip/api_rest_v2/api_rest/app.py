from flask import Flask
from flask_restful import Api, Resource, reqparse
from models import db, ProductModel, UserModel, PedidoModel

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///products.db'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///user.db'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///pedidos.db'
db.init_app(app)
api = Api(app)
with app.app_context():
    db.create_all()
class Product(Resource):
    def get(self, prod_id=None):
        if prod_id:
            prod = ProductModel.query.filter_by(id=prod_id).first()
            if prod:
                return {'id': prod.id, 'name': prod.name, 'price': prod.price, 'stock': prod.stock}, 200
            else:
                return {'error': 'Task not found'}, 404
        else:
            prod = ProductModel.query.all()
            return [{'id': prod.id, 'name': prod.name, 'price': prod.price, 'stock': prod.stock} for prod in prod], 200

class Users(Resource):
    def get(self, user_id=None):
        if user_id:
            Users = UserModel.query.filter_by(id=user_id).first()
            if Users:
                return {'id': Users.id, 'name': Users.name, 'email': Users.email, 'age': Users.age}, 200
            else:
                return {'error': 'Task not found'}, 404
        else:
            Users = UserModel.query.all()
            return [{'id': Users.id, 'name': Users.name, 'email': Users.email, 'age': Users.age} for Users in Users], 200

    #def get(self, user_email=None):
        #if user_email:
            #Users = UserModel.query.filter_by(email=user_email).first()
            #if Users:
                #return {'id': Users.id, 'name': Users.name, 'email': Users.email, 'age': Users.age}, 200
            #else:
                #return {'error': 'Task not found'}, 404
        #else:
            #Users = UserModel.query.all()
            #return [{'id': Users.id, 'name': Users.name, 'email': Users.email, 'age': Users.age} for Users in Users], 200

class Pedidos(Resource):
    def get(self, pedido_id=None):
        if pedido_id:
            pedi = PedidoModel.query.filter_by(id=pedido_id).first()
            if pedi:
                return {'id': pedi.id, 'idu': pedi.idu, 'descricao': pedi.descricao, 'status': pedi.status}, 200
            else:
                return {'error': 'Task not found'}, 404
        else:
            pedi = PedidoModel.query.all()
            return [{'id': pedi.id, 'idu': pedi.idu, 'descricao': pedi.descricao, 'status': pedi.status} for pedi in pedi], 200

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('name', type=str, required=True, help='name is required')
        parser.add_argument('price', type=float)
        parser.add_argument('stock', type=int)

        args = parser.parse_args()

        prod = ProductModel(name=args['name'], price=args['price'], stock=args['stock'])
        db.session.add(prod)
        db.session.commit()
        return {'id': prod.id, 'name': prod.name, 'price': prod.price, 'stock': prod.stock}, 201


    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('name', type=str, required=True, help='name is required')
        parser.add_argument('email', type=str)
        parser.add_argument('age', type=int)

        args = parser.parse_args()

        Users = UserModel(name=args['name'], email=args['email'], age=args['age'])
        db.session.add(Users)
        db.session.commit()
        return {'id': Users.id, 'name': Users.name, 'email': Users.email, 'age': Users.age}, 201

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('idu', type=int, required=True, help='ID is required')
        parser.add_argument('descricao', type=str)
        parser.add_argument('status', type=str)

        args = parser.parse_args()

        pedi = PedidoModel(idu=args['idu'], descricao=args['descricao'], status=args['status'])
        db.session.add(pedi)
        db.session.commit()
        return {'id': pedi.id, 'idu': pedi.idu, 'descricao': pedi.descricao, 'status': pedi.status}, 201

    def put(self, prod_id):
        prod = ProductModel.query.filter_by(id=prod_id).first()
        if prod:
            parser = reqparse.RequestParser()
            parser.add_argument('name', type=str, required=True, help='name is required')
            parser.add_argument('price', type=float)
            parser.add_argument('stock', type=int)

            args = parser.parse_args()

            prod.name = args['name']
            prod.price = args['price']
            prod.stock = args['stock']
            db.session.commit()
            return {'id': prod.id, 'name': prod.name, 'price': prod.price, 'stock': prod.stock}, 200
        else:
            return {'error': 'Task not found'}, 404


    def put(self, user_id):
        Users = UserModel.query.filter_by(id=user_id).first()
        if Users:
            parser = reqparse.RequestParser()
            parser.add_argument('name', type=str, required=True, help='name is required')
            parser.add_argument('email', type=str)
            parser.add_argument('age', type=int)

            args = parser.parse_args()

            Users.name = args['name']
            Users.email = args['email']
            Users.age = args['age']
            db.session.commit()
            return {'id': Users.id, 'name': Users.name, 'email': Users.email, 'age': Users.age}, 200
        else:
            return {'error': 'Task not found'}, 404

    def put(self, pedido_id):
        pedi = PedidoModel.query.filter_by(id=pedido_id).first()
        if pedi:
            parser = reqparse.RequestParser()
            parser.add_argument('idu', type=int, required=True, help='ID is required')
            parser.add_argument('descricao', type=str)
            parser.add_argument('status', type=str)

            args = parser.parse_args()

            pedi.idu = args['idu']
            pedi.descricao = args['descricao']
            pedi.status = args['status']
            db.session.commit()
            return {'id': pedi.id, 'idu': pedi.idu, 'descricao': pedi.descricao, 'status': pedi.status}, 200
        else:
            return {'error': 'Task not found'}, 404

    def delete(self, prod_id):
        prod = ProductModel.query.filter_by(id=prod_id).first()
        if prod:
            db.session.delete(prod)
            db.session.commit()
            return '', 204
        else:
            return {'error': 'Prod not found'}, 404

    def delete(self, user_id):
        Users = UserModel.query.filter_by(id=user_id).first()
        if Users:
            db.session.delete(Users)
            db.session.commit()
            return '', 204
        else:
            return {'error': 'User not found'}, 404

    def delete(self, pedido_id):
        pedi = PedidoModel.query.filter_by(id=pedido_id).first()
        if pedi:
            db.session.delete(pedi)
            db.session.commit()
            return '', 204
        else:
            return {'error': 'Pedido not found'}, 404

api.add_resource(Product, '/products', '/products/<int:prod_id>')
api.add_resource(Users, '/users', '/users/<int:user_id>')
api.add_resource(Pedidos, '/pedidos', '/pedidos/<int:pedido_id>')

if __name__ == '__main__':
    app.run(debug=True)
import requests



data = {
"id" : 1
"name" : "José"
"email" : "jose.silva@gmail.com"
"age" : 33
}

response = requests.post('http://localhost:5000/users', json=data)

if response.status_code == 201:

    task = response.json()

    print(task)

else:

    print('Error:', response.text)
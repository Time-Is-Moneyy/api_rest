def get_user():
    search_param = request.args.get(search_param)
    if search_param.isdigit():
        user = User.query.filter_by(id=search_param).first()
    else:
        user = User.query.filter_by(email=search_param).first()

    if user:
        return jsonify({'id': user.id, 'name': user.name, 'email': user.email, 'age': user.age}), 200
    else:
        return jsonify({'message': 'Usuário não encontrado'}), 404

get_user()
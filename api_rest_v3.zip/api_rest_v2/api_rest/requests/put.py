import requests



data = {

    'title': 'Comprar pão',

    'description': 'Comprar pão na padaria'

}

response = requests.put('http://localhost:5000/tasks/1', json=data)

if response.status_code == 200:

    task = response.json()

    print(task)

else:

    print('Error:', response.text)
import requests



response = requests.delete('http://localhost:5000/tasks/1')

if response.status_code == 204:

    print('Task deleted')

else:

    print('Error:', response.text)